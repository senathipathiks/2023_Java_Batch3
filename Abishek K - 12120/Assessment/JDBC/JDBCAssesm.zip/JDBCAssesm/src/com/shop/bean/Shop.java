package com.shop.bean;

public class Shop {

	int TransID;
	String Itemname;
	String Description;
	float Price;
	String Seller;
	String Buyer;
	String Paymentmode;
	String Paymentstatus;
	
	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Shop(int transID, String itemname, String description, float price, String seller, String buyer,
			String paymentmode, String paymentstatus) {
		super();
		TransID = transID;
		Itemname = itemname;
		Description = description;
		Price = price;
		Seller = seller;
		Buyer = buyer;
		Paymentmode = paymentmode;
		Paymentstatus = paymentstatus;
	}

	public int getTransID() {
		return TransID;
	}

	public void setTransID(int transID) {
		TransID = transID;
	}

	public String getItemname() {
		return Itemname;
	}

	public void setItemname(String itemname) {
		Itemname = itemname;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public float getPrice() {
		return Price;
	}

	public void setPrice(float price) {
		Price = price;
	}

	public String getSeller() {
		return Seller;
	}

	public void setSeller(String seller) {
		Seller = seller;
	}

	public String getBuyer() {
		return Buyer;
	}

	public void setBuyer(String buyer) {
		Buyer = buyer;
	}

	public String getPaymentmode() {
		return Paymentmode;
	}

	public void setPaymentmode(String paymentmode) {
		Paymentmode = paymentmode;
	}

	public String getPaymentstatus() {
		return Paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		Paymentstatus = paymentstatus;
	}
	
	
	
	
	
}
