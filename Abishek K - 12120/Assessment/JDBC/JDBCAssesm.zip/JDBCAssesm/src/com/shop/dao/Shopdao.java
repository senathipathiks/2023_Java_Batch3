package com.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.shop.bean.Shop;
import com.shop.util.DBUtil;

public class Shopdao {

	public int insertShop(Shop st1) throws SQLException {
		
		int n=0;
		
		Connection con = DBUtil.getDBConnection();
		
		String sql = "insert into shopping values(?,?,?,?,?,?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setInt(1, st1.getTransID() );
		ps.setString(2,st1.getItemname());
		ps.setString(3, st1.getDescription());
		ps.setFloat(4, st1.getPrice());
		ps.setString(5, st1.getSeller());
		ps.setString(6, st1.getBuyer());
		ps.setString(7, st1.getPaymentmode());
		ps.setString(8, st1.getPaymentstatus());
		
		n=ps.executeUpdate();
		return n;
		
		
	}
	
	public int deleteShop(int it) throws SQLException {
		int n;
		
		Connection con = DBUtil.getDBConnection();
		
		String sql = "delete from shopping where TransID=?";
		
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setInt(1, it);
		
		n=ps.executeUpdate();
		return n;
}
	
	public int updateShop() throws SQLException {
		
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter specific Transcation ID to update Data");
		int id=sc.nextInt();
		System.out.println("Change Item-Name");
		String itname = sc.next();
		System.out.println("Change Item-Description");
		String desc = sc.next();
		System.out.println("Change Item-Price");
		float price = sc.nextFloat();
		System.out.println("Change Payment-status");
		String pay = sc.next();
		
		
		Connection con = DBUtil.getDBConnection();
		
		String sql = "update shopping set Itemname=?,description=?,Price=?,Paymentstatus=? where TransID=?";
		
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setString(1, itname);
		ps.setString(2, desc);
		ps.setFloat(3, price);
		ps.setString(4, pay);
		ps.setInt(5,id);
		
		n=ps.executeUpdate();
		return n;
	}
	
	public ResultSet findShop(int it1) throws SQLException {
		
		int n;
		
		Connection con = DBUtil.getDBConnection();
		
		String sql = "select * from shopping where TransID=?";
		
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setInt(1,it1);
		
		ResultSet rs = ps.executeQuery();
		
		return rs;
	}
	
       public ResultSet findAllShop() throws SQLException {
		
		int n;
		
		Connection con = DBUtil.getDBConnection();
		
		String sql = "select * from shopping";
		
		PreparedStatement ps = con.prepareStatement(sql);
		
		ResultSet rs = ps.executeQuery();
		
		return rs;
	}
	
	
}

