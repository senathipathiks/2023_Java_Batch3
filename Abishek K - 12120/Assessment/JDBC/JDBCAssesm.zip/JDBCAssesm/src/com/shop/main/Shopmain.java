package com.shop.main;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.shop.bean.Shop;
import com.shop.dao.Shopdao;

public class Shopmain {
	
	static Scanner sc = new Scanner(System.in);
	
	public static int displayMenu() {
		System.out.println("1.Insert Data \n2.Delete Data \n3.Update Data \n4.Find \n5.Find All \n6.Exit ");
		System.out.println("Enter Your choice");
		return(sc.nextInt());
		
	}
	
	public static Shop insertShop(){
		System.out.println("Enter the Data to Insert TransID, ItemName, Description, Price, Seller, Buyer, PaymentMode, PaymentStatus ");
		return new Shop(sc.nextInt(),sc.next(),sc.next(),sc.nextFloat(),sc.next(),sc.next(),sc.next(),sc.next());
	}
	
	public static int deleteShop() {
		System.out.println("Enter the Transcation ID to delete");
		return(sc.nextInt());
	}
	
    public static void updateShop() {
    	System.out.println("You can update your Database");
    }
    
    public static int findShop() {
    	System.out.println("Enter the Specific Transcation ID to View Details");
    	return (sc.nextInt());
    }
    
    public static void findAllShop() {
    	System.out.println("View of the Table");
    }

	public static void main(String[] args) throws SQLException {
		
		int n=0;
		String msg =" ";
		
		Shopdao dao = new Shopdao(); 
		
		do {
			
			switch(displayMenu()) {
			case 1:
			
				Shop st1 = insertShop();
				n=dao.insertShop(st1);	
				
				if(n==1) {
					System.out.println("Insertion is Successfully Done");
				}
				else {
					System.out.println("Insertion is Failure");
					
				}
				break;
				
			case 2:
				
				int it = deleteShop();
				n=dao.deleteShop(it);
				
				if(n==1) {
					System.out.println("Deletion is SuccessFully Done");
				}
				
				else {
					System.out.println("Deletion is Failure");
				}
				break;
				
			case 3:
				
				updateShop();
				n=dao.updateShop();
				
				if(n==1) {
					System.out.println("Update is Successfully Done");
				}
				else {
					System.out.println("Update is Failure");
				}
				break;
				
			case 4:
				
				int it1=findShop();
				ResultSet rs = dao.findShop(it1);
				
				while(rs.next()) {
					System.out.println("TransID: "+rs.getInt(1)+"\nItem-Name: "+rs.getString(2)+"\nItem-Descrption: "+rs.getString(3)+"\nItem-price: "+rs.getFloat(4)+"\nItem-Seller: "+rs.getString(5)+"\nItem-Buyer: "+rs.getString(6)+"\nPayment-Mode: "+rs.getString(7)+"\nPayment-Status: "+rs.getString(8));
					
				}
				break;
				
			case 5:
				findAllShop();
                ResultSet rs1 = dao.findAllShop();
				
				while(rs1.next()) {
					System.out.println("TransID: "+rs1.getInt(1)+"\nItem-Name: "+rs1.getString(2)+"\nItem-Descrption: "+rs1.getString(3)+"\nItem-price: "+rs1.getFloat(4)+"\nItem-Seller: "+rs1.getString(5)+"\nItem-Buyer: "+rs1.getString(6)+"\nPayment-Mode: "+rs1.getString(7)+"\nPayment-Status: "+rs1.getString(8)+"\n------------------------------------------------");
					
				}
				break;
				
			case 6:
				System.out.println("****Thank You****");
				System.exit(0);
				break;
				
			default:
				System.out.println("Enter Valid Input");
				
				
				
				
				
			
			}
			System.out.println("Do You want to continue yes/no");
			msg=sc.next();
			
		}
		while(msg.equals("yes"));

	}

}
