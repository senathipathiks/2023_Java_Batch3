import React from 'react'

function Read() {
  return (
    <div>
      
    </div>
  )
}

export default Read
