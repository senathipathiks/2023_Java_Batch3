package com.hotel.bean;

public class Hotel {

	private int rmID;
	private String rmType;
	private int  rmTariff;
	private String rmDesc;
	private String rmOccup;
	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hotel(int rmID, String rmType, int rmTariff, String rmDesc, String rmOccup) {
		super();
		this.rmID = rmID;
		this.rmType = rmType;
		this.rmTariff = rmTariff;
		this.rmDesc = rmDesc;
		this.rmOccup = rmOccup;
	}

	public int getRmID() {
		return rmID;
	}

	public void setRmID(int rmID) {
		this.rmID = rmID;
	}

	public String getRmType() {
		return rmType;
	}

	public void setRmType(String rmType) {
		this.rmType = rmType;
	}

	public int getRmTariff() {
		return rmTariff;
	}

	public void setRmTariff(int rmTariff) {
		this.rmTariff = rmTariff;
	}

	public String getRmDesc() {
		return rmDesc;
	}

	public void setRmDesc(String rmDesc) {
		this.rmDesc = rmDesc;
	}

	public String getRmOccup() {
		return rmOccup;
	}

	public void setRmOccup(String rmOccup) {
		this.rmOccup = rmOccup;
	}
	
	
	
}
