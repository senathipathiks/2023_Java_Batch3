package com.hotel.hoteldao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.hotel.DBUtil.DBUtil;
import com.hotel.bean.Hotel;

public class HotelDao {
	
	public int hotelInsert(Hotel htl) {
		
		int n=0;
		
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "insert into hotel values(?,?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,htl.getRmID());
			ps.setString(2,htl.getRmType());
			ps.setInt(3, htl.getRmTariff());
			ps.setString(4, htl.getRmDesc());
			ps.setString(5, htl.getRmOccup());
			n=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
		
	}
	
	public Hotel hotelFind(int id) {
		
		Hotel htl = null;
		int n=0;
		ResultSet rs = null;
		
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "select * from hotel where RoomID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			rs=ps.executeQuery();
			while(rs.next()) {
				htl = new Hotel();
				htl.setRmID(rs.getInt(1));
				htl.setRmType(rs.getString(2));
				htl.setRmTariff(rs.getInt(3));
				htl.setRmDesc(rs.getString(4));
				htl.setRmOccup(rs.getString(5));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return htl;
		
	}
	
	public ArrayList<Hotel> hotelFindall(){
		
		ArrayList<Hotel> list = new ArrayList<Hotel>();
		Hotel htl = null;
		ResultSet rs = null;
		
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "select * from hotel";
			PreparedStatement ps = con.prepareStatement(sql);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				htl = new Hotel();
				htl.setRmID(rs.getInt(1));
				htl.setRmType(rs.getString(2));
				htl.setRmTariff(rs.getInt(3));
				htl.setRmDesc(rs.getString(4));
				htl.setRmOccup(rs.getString(5));
				list.add(htl);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	public int hotelUpdate(Hotel htl) {
		
		int n=0;
		
		Connection con;
		try {
			con = DBUtil.getDBConnection();
			String sql = "update hotel set RoomType=?,RoomTariff=?,RoomDesc=?,RoomOccup=? where RoomID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, htl.getRmType());
			ps.setInt(2, htl.getRmTariff());
			ps.setString(3, htl.getRmDesc());
			ps.setString(4, htl.getRmOccup());
			ps.setInt(5, htl.getRmID());
			n=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
		
	}
	
	public int hotelDelete(int id) {
		
		int n=0;
		
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "delete from hotel where RoomID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			n=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
		
		
	}

}
