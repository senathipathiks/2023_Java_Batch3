package com.hotel.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.hotel.bean.Hotel;
import com.hotel.hoteldao.HotelDao;


public class MainController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int n=0;
		HotelDao dao = new HotelDao();
		PrintWriter out = response.getWriter();
		
		String action = request.getParameter("button");
		
		if(action.equals("Insert")) {
			
			int rmID = Integer.parseInt(request.getParameter("rmid"));
			String rmType = request.getParameter("rmtype");
			int  rmTariff = Integer.parseInt(request.getParameter("rmtariff"));
			String rmDesc = request.getParameter("rmdesc");
			String rmOccup = request.getParameter("rmoccup");
			
			Hotel htl = new Hotel(rmID, rmType, rmTariff, rmDesc, rmOccup);
			n= dao.hotelInsert(htl);
			
			if(n>0) {
				response.sendRedirect("Success.jsp?action=Insert");
			}
			else {
				response.sendRedirect("Failure.jsp?action=Insert");
			}
			
			
			
		}
		else if(action.equals("Find")) {
			
			int id = Integer.parseInt(request.getParameter("rmid"));
			
			Hotel htl = dao.hotelFind(id);
			
			if(htl!=null) {
				request.getSession().setAttribute("bean", htl);
				response.sendRedirect("Success.jsp?action=Find");
			}
			else {
				response.sendRedirect("Failure.jsp?action=Find");
			}
			
		}
		
		else if(action.equals("FindAll")) {
			
			ArrayList<Hotel> list = new ArrayList<Hotel>();
			list = dao.hotelFindall();
			
			if(list.size()!=0) {
				request.getSession().setAttribute("list", list);
				response.sendRedirect("Success.jsp?action=FindAll");
			}
			else {
				response.sendRedirect("Failure.jsp?action=FinAll");
			}
			
		}
		
		else if(action.equals("Update")) {
			
			int rmID = Integer.parseInt(request.getParameter("rmid"));
			String rmType = request.getParameter("rmtype");
			int  rmTariff = Integer.parseInt(request.getParameter("rmtariff"));
			String rmDesc = request.getParameter("rmdesc");
			String rmOccup = request.getParameter("rmoccup");
			
			Hotel htl = new Hotel(rmID, rmType, rmTariff, rmDesc, rmOccup);
			n= dao.hotelUpdate(htl);
			
			if(n>0) {
				response.sendRedirect("Success.jsp?action=Update");
			}
			else {
				response.sendRedirect("Failure.jsp?action=Update");
			}
			
		}
		
		else if(action.equals("Delete")) {
			
			int id = Integer.parseInt(request.getParameter("rmid"));
			
			n=dao.hotelDelete(id);
			
			if(n>0) {
				response.sendRedirect("Success.jsp?action=Delete");
			}
			else {
				response.sendRedirect("Failure.jsp?action=Delete");
			}
			
		}
		
	}

}
