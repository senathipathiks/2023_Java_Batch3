import MockAxios from "jest-mock-axios";

export default MockAxios;
