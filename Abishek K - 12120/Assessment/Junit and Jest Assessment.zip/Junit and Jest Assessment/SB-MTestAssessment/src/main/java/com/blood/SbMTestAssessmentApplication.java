package com.blood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbMTestAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMTestAssessmentApplication.class, args);
	}

}
