-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: car
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car` (
  `carid` int NOT NULL,
  `carname` varchar(20) DEFAULT NULL,
  `carcolor` varchar(20) DEFAULT NULL,
  `carmodel` varchar(20) DEFAULT NULL,
  `carmileage` int DEFAULT NULL,
  `carnumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`carid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (1,'TATA','red','suv',25,'TN28 AM2139'),(2,'BENZ','blue','sedan',12,'TN23 AK8362'),(3,'BMW','grey','suv',23,'TN12 AO 1258'),(4,'AUDI','green','suv',21,'TN54 AW 7863'),(5,'MG HECTOR','black','suv',14,'TN34 AZ 0124');
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `custid` int NOT NULL,
  `custname` varchar(20) DEFAULT NULL,
  `custph` varchar(20) DEFAULT NULL,
  `custemail` varchar(20) DEFAULT NULL,
  `custadd` varchar(20) DEFAULT NULL,
  `carid` int DEFAULT NULL,
  PRIMARY KEY (`custid`),
  KEY `carid` (`carid`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`carid`) REFERENCES `car` (`carid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Abishek','65756496','Abi@gmail.com','Namakkal',5),(2,'Prem','597464879','prem@gmail.com','salem',4),(3,'vishnu','47815484','vishnu@gmail.com','tiruppur',3),(4,'dharsan','45878564','dharsan@gmail.com','pondy',2),(5,'loki','678152658','loki@gmail.com','theni',1);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental`
--

DROP TABLE IF EXISTS `rental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental` (
  `rentalid` int NOT NULL,
  `rentalstartdate` varchar(20) DEFAULT NULL,
  `rentalenddate` varchar(20) DEFAULT NULL,
  `carid` int DEFAULT NULL,
  `custid` int DEFAULT NULL,
  PRIMARY KEY (`rentalid`),
  KEY `carid` (`carid`),
  KEY `custid` (`custid`),
  CONSTRAINT `rental_ibfk_1` FOREIGN KEY (`carid`) REFERENCES `car` (`carid`),
  CONSTRAINT `rental_ibfk_2` FOREIGN KEY (`custid`) REFERENCES `customer` (`custid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental`
--

LOCK TABLES `rental` WRITE;
/*!40000 ALTER TABLE `rental` DISABLE KEYS */;
INSERT INTO `rental` VALUES (1,'17/01/23','20/01/23',5,4),(2,'12/01/23','14/01/23',4,5),(3,'10/01/23','12/01/23',3,2),(4,'02/01/23','18/01/23',2,3),(5,'20/01/23','25/01/23',1,2);
/*!40000 ALTER TABLE `rental` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesman`
--

DROP TABLE IF EXISTS `salesman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salesman` (
  `salesmanid` int NOT NULL,
  `salesmanname` varchar(20) DEFAULT NULL,
  `salesmanph` varchar(20) DEFAULT NULL,
  `rentalid` int DEFAULT NULL,
  PRIMARY KEY (`salesmanid`),
  KEY `rentalid` (`rentalid`),
  CONSTRAINT `salesman_ibfk_1` FOREIGN KEY (`rentalid`) REFERENCES `rental` (`rentalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesman`
--

LOCK TABLES `salesman` WRITE;
/*!40000 ALTER TABLE `salesman` DISABLE KEYS */;
INSERT INTO `salesman` VALUES (1,'priya','57498584',4),(2,'keerthy','58884961',3);
/*!40000 ALTER TABLE `salesman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcation`
--

DROP TABLE IF EXISTS `transcation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transcation` (
  `transcationid` int NOT NULL,
  `transcationtype` varchar(20) DEFAULT NULL,
  `custid` int DEFAULT NULL,
  `salesmanid` int DEFAULT NULL,
  `rentalid` int DEFAULT NULL,
  PRIMARY KEY (`transcationid`),
  KEY `custid` (`custid`),
  KEY `salesmanid` (`salesmanid`),
  KEY `rentalid` (`rentalid`),
  CONSTRAINT `transcation_ibfk_1` FOREIGN KEY (`custid`) REFERENCES `customer` (`custid`),
  CONSTRAINT `transcation_ibfk_2` FOREIGN KEY (`salesmanid`) REFERENCES `salesman` (`salesmanid`),
  CONSTRAINT `transcation_ibfk_3` FOREIGN KEY (`rentalid`) REFERENCES `rental` (`rentalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcation`
--

LOCK TABLES `transcation` WRITE;
/*!40000 ALTER TABLE `transcation` DISABLE KEYS */;
INSERT INTO `transcation` VALUES (1,'cash',1,2,3),(2,'gpay',2,1,2),(3,'bharatpay',3,2,5),(4,'Account transfer',4,1,1);
/*!40000 ALTER TABLE `transcation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-19 16:27:52
