package com.sbempapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbStudentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbStudentAppApplication.class, args);
	}

}
