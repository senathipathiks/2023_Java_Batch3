# Employee-Management-REST-API-using-SpringBoot-SpringDataJPA
In this project, we have designed REST APIs for all CRUD operations that can be used for Employee Management, using Spring Boot features and saving the data in MySQL using Spring Data JPA. 

A new Maven project can be pre-designed using Spring Boot.

www.start.spring.io
