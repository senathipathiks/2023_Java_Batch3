package com.pms.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pms.bean.Property;
import com.pms.util.HibernateUtil;

public class PropertyDAO {

    public int insertProperty(Property property) {
        int n = 0;
        try {
            Session session = HibernateUtil.opensession();
            Transaction transaction = session.beginTransaction();
            session.persist(property);
            transaction.commit();
            n = 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return n;
    }

    public ArrayList<Integer> getPropertyIds() {
        ArrayList<Integer> idList = new ArrayList<>();
        Session session = HibernateUtil.opensession();
        idList = (ArrayList<Integer>) session.createQuery("select propID from Property").list();
        Transaction transaction = session.beginTransaction();
        session.close();
        return idList;
    }

    public boolean deleteProperty(Property property) {
        try {
            Session session = HibernateUtil.opensession();
            Transaction t = session.beginTransaction();
            session.delete(property);
            t.commit();
            session.close();
            return true;
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public Property getProperty(Property p) {
        try {
            Session session = HibernateUtil.opensession();
            Property property = session.get(Property.class, p.getPropID());
            session.close();
            return property;
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;

    }

    public boolean updateProperty(Property property) {
        try {
            Session session = HibernateUtil.opensession();
            Property p = session.get(Property.class, property.getPropID());

            if (p != null) {
                Transaction t = session.beginTransaction();
                p.setPropName(property.getPropName());
                p.setPropType(property.getPropType());
                p.setCity(property.getCity());
                p.setCountry(property.getCountry());
                p.setYear_of_purchase(property.getYear_of_purchase());
                p.setSeller(property.getSeller());
                session.update(p);
                t.commit();
                session.close();
                return true;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return false;

    }

    public ArrayList<Property> getPropertiesList() {
        ArrayList<Property> list = new ArrayList<>();
        Session session = HibernateUtil.opensession();
        list = (ArrayList<Property>) session.createQuery("from Property").list();
        return list;
    }
}
