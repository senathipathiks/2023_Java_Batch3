package com.pms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pms.bean.Property;
import com.pms.dao.PropertyDAO;

@Controller
public class PropertyController {
    @Autowired
    PropertyDAO dao;

    @RequestMapping("Header")
    public ModelAndView loadHeader() {
        ModelAndView mv = new ModelAndView("Header");
        return mv;
    }
    @RequestMapping("AboutUs")
    public ModelAndView loadAboutUs() {
        ModelAndView mv = new ModelAndView("AboutUs");
        return mv;
    }

    @RequestMapping("Home")
    public ModelAndView loadHome() {
        ModelAndView mv = new ModelAndView("Home");
        return mv;
    }

    @RequestMapping("Links")
    public ModelAndView loadLinks() {
        ModelAndView mv = new ModelAndView("Links");
        return mv;
    }

    @RequestMapping("InsertProperty")
    public ModelAndView loadInsertProperty() {
        return new ModelAndView("InsertProperty");
    }

    @PostMapping("InsertionProperty")
    public ModelAndView doInsertProperty(@ModelAttribute("bean") Property property) {
        int n = dao.insertProperty(property);

        if (n == 1)
            return new ModelAndView("InsertProperty").addObject("msg", "Record Inserted Successfully");
        return new ModelAndView("InsertProperty").addObject("msg", "Record Inserted Failure");
    }

    @RequestMapping("DeleteProperty")
    public ModelAndView loadDeleteProperty() {
        return new ModelAndView("DeleteProperty").addObject("key", dao.getPropertyIds());
    }

    @PostMapping("DeletionProperty")
    public ModelAndView doDeleteProperty(@ModelAttribute("bean") Property property) {
        if (dao.deleteProperty(property))
            return new ModelAndView("DeleteProperty").addObject("key", dao.getPropertyIds())
                    .addObject("msg", "Record Deleted Successfully");
        return new ModelAndView("DeleteProperty").addObject("key", dao.getPropertyIds())
                .addObject("msg", "Record Deleted Failure");
    }

    @RequestMapping("UpdateProperty")
    public ModelAndView loadUpdateProperty() {
        return new ModelAndView("UpdateProperty").addObject("key", dao.getPropertyIds());
    }

    @PostMapping("FetchProperty")
    public ModelAndView doFetchProperty(@ModelAttribute("bean") Property property) {
        return new ModelAndView("UpdateProperty").addObject("key", dao.getPropertyIds())
                .addObject("property", dao.getProperty(property));
    }

    @PostMapping("UpdationProperty")
    public ModelAndView doUpdateProperty(@ModelAttribute("bean") Property property) {
        if (dao.updateProperty(property))
            return new ModelAndView("UpdateProperty").addObject("key", dao.getPropertyIds())
                    .addObject("msg", "Record Updated Successfully");
        return new ModelAndView("UpdateProperty").addObject("key", dao.getPropertyIds())
                .addObject("msg", "Record Updated Failure");
    }

    @RequestMapping("FindProperty")
    public ModelAndView loadFindProperty() {
        return new ModelAndView("FindProperty").addObject("key", dao.getPropertyIds());
    }

    @PostMapping("FindProperty")
    public ModelAndView doFindProperty(@ModelAttribute("bean") Property property) {
        Property foundProperty = dao.getProperty(property);
        if (foundProperty != null)
            return new ModelAndView("FindProperty").addObject("key", dao.getPropertyIds()).addObject("bean", foundProperty);
        return new ModelAndView("FindProperty").addObject("key", dao.getPropertyIds()).addObject("msg", "Record not found");
    }

    @RequestMapping("FindAllProperties")
    public ModelAndView loadFindAllProperties() {
        return new ModelAndView("FindAllProperties").addObject("list", dao.getPropertiesList());
    }

    @RequestMapping("EditProperty")
    public ModelAndView doEditProperty(@ModelAttribute("bean") Property property) {
        dao.updateProperty(property);
        return new ModelAndView("FindAllProperties").addObject("list", dao.getPropertiesList());
    }

    @RequestMapping("DeleteNowProperty")
    public ModelAndView doDeleteNowProperty(@RequestParam("bean") Integer id) {
        Property property = new Property();
        property.setPropID(id);
        dao.deleteProperty(property);
        return new ModelAndView("FindAllProperties").addObject("list", dao.getPropertiesList());
    }

    @RequestMapping("AddProperty")
    public ModelAndView doAddProperty(@ModelAttribute("bean") Property property) {
        dao.insertProperty(property);
        return new ModelAndView("FindAllProperties").addObject("list", dao.getPropertiesList());
    }
}
