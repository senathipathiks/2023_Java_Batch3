package com.pms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "property_tbl")
public class Property {
    @Id
    private int propID;
    private String propName;
    private String propType;
    private String city;
    private String country;
    private String year_of_purchase;
    private String seller;

    public Property() {
        super();
    }

    public Property(int propID, String propName, String propType, String city, String country, String year_of_purchase, String seller) {
        super();
        this.propID = propID;
        this.propName = propName;
        this.propType = propType;
        this.city = city;
        this.country = country;
        this.year_of_purchase = year_of_purchase;
        this.seller = seller;
    }

    public int getPropID() {
        return propID;
    }

    public void setPropID(int propID) {
        this.propID = propID;
    }

    public String getPropName() {
        return propName;
    }

    public void setPropName(String propName) {
        this.propName = propName;
    }

    public String getPropType() {
        return propType;
    }

    public void setPropType(String propType) {
        this.propType = propType;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getYear_of_purchase() {
        return year_of_purchase;
    }

    public void setYear_of_purchase(String year_of_purchase) {
        this.year_of_purchase = year_of_purchase;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }
}
