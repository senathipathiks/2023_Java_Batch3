package com.lms.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import com.lms.bean.Book;
import com.lms.dao.BookDAO;

@WebServlet("/BookServlet")
public class InsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int n = 0;
        BookDAO dao = new BookDAO();
        PrintWriter out = response.getWriter();
        String action = request.getParameter("button");
        System.out.println(action + " action");

        if (action.equals("Insert")) {
            RequestDispatcher rd = request.getRequestDispatcher("insert.jsp");
            int bookID = Integer.parseInt(request.getParameter("bookID"));
            String bookName = request.getParameter("bookName");
            String author = request.getParameter("author");
            String publisher = request.getParameter("publisher");
            float price = Float.parseFloat(request.getParameter("price"));
            int edition = Integer.parseInt(request.getParameter("edition"));
            Book book = new Book(bookID, bookName, author, publisher, price, edition);
            n = dao.insertBook(book);

            if (n == 1) {
                // Set success message as attribute
                request.setAttribute("message", "Book Inserted Successfully");

                // Forward to success JSP page
                RequestDispatcher rd1 = request.getRequestDispatcher("InsertBookSuccess.jsp");
                rd1.forward(request, response);
            } else {
                // Set failure message as attribute
                request.setAttribute("message", "Book Insertion Failure");

                // Forward to failure JSP page
                RequestDispatcher rd1 = request.getRequestDispatcher("InsertBookFailure.jsp");
                rd1.forward(request, response);
            }
        } else if (action.equals("Find")) {
            int bookID = Integer.parseInt(request.getParameter("bookID"));

            Book book = dao.findBook(bookID);

            if (book != null) {
                request.setAttribute("bookID", book.getBookID());
                request.setAttribute("bookName", book.getBookName());
                request.setAttribute("author", book.getAuthor());
                request.setAttribute("publisher", book.getPublisher());
                request.setAttribute("price", book.getPrice());
                request.setAttribute("edition", book.getEdition());

                RequestDispatcher rd = request.getRequestDispatcher("FindBook.jsp");
                rd.forward(request, response);
            } else {
                // If book is not found, forward to NoBook.jsp
                RequestDispatcher rd1 = request.getRequestDispatcher("NoBook.jsp");
                rd1.forward(request, response);
            }
        }
        else if (action.equals("Find All")) {
            LinkedList<Book> books = dao.findAllBooks();

            if (books.size() > 0) {
                request.setAttribute("bookList", books);

                RequestDispatcher rd1 = request.getRequestDispatcher("BookList.jsp");
                rd1.forward(request, response);
            }
        } else if (action.equals("Update")) {
            int bookID = Integer.parseInt(request.getParameter("bookID"));
            String bookName = request.getParameter("bookName");
            String author = request.getParameter("author");
            String publisher = request.getParameter("publisher");
            float price = Float.parseFloat(request.getParameter("price"));
            int edition = Integer.parseInt(request.getParameter("edition"));
            Book book = new Book(bookID, bookName, author, publisher, price, edition);
            n = dao.updateBook(book);

            if (n == 1) {
                RequestDispatcher rd = request.getRequestDispatcher("UpdateBookSuccess.jsp");
                rd.forward(request, response);
            } else {
                RequestDispatcher rd1 = request.getRequestDispatcher("UpdateBookFailure.jsp");
                rd1.forward(request, response);
            }
        }
        
        else if(action.equals("Delete"))
        {
			int bookID = Integer.parseInt(request.getParameter("bookID"));
			n = dao.deleteBook(bookID);

			if (n == 1) {
				RequestDispatcher rd = request.getRequestDispatcher("DeleteSuccess.jsp");
				rd.forward(request, response);
			} else {

				RequestDispatcher rd = request.getRequestDispatcher("DeleteFailure.jsp");
				rd.forward(request, response);

			}
		}

	}
}

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
