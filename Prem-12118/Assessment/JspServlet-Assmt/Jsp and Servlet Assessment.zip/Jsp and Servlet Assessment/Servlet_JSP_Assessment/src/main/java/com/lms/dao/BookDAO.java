package com.lms.dao;

import java.sql.*;
import java.util.LinkedList;

import com.lms.bean.Book;
import com.lms.util.DBUtil;

public class BookDAO {

    public int insertBook(Book book) {
        int n = 0;
        try {
            Connection con = DBUtil.getDBConnection();
            String sql = "insert into books values(?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, book.getBookID());
            ps.setString(2, book.getBookName());
            ps.setString(3, book.getAuthor());
            ps.setString(4, book.getPublisher());
            ps.setFloat(5, book.getPrice());
            ps.setInt(6, book.getEdition());
            n = ps.executeUpdate();

        } catch (Exception e) {
            System.out.println(e);
        }
        return n;
    }

    public int updateBook(Book book) {
        int n = 0;
        try {
            Connection con = DBUtil.getDBConnection();
            String sql = "update books set bookName=?, author=?, publisher=?, price=?, edition=? where bookID=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, book.getBookName());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getPublisher());
            ps.setFloat(4, book.getPrice());
            ps.setInt(5, book.getEdition());
            ps.setInt(6, book.getBookID());
            n = ps.executeUpdate();

        } catch (Exception e) {
            System.out.println(e);
        }
        return n;
    }

    public Book findBook(int bookID) {
        Book book = new Book();
        try {
            Connection con = DBUtil.getDBConnection();
            String sql = "select * from books where bookID=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, bookID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                book.setBookID(rs.getInt(1));
                book.setBookName(rs.getString(2));
                book.setAuthor(rs.getString(3));
                book.setPublisher(rs.getString(4));
                book.setPrice(rs.getFloat(5));
                book.setEdition(rs.getInt(6));
            } else {
                System.out.println("Book not found");
                // Handle the case when the book is not found
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return book;
    }

    public LinkedList<Book> findAllBooks() {
        LinkedList<Book> list = new LinkedList<Book>();
        try {
            Connection con = DBUtil.getDBConnection();
            String sql = "select * from books";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Book book = new Book();
                book.setBookID(rs.getInt(1));
                book.setBookName(rs.getString(2));
                book.setAuthor(rs.getString(3));
                book.setPublisher(rs.getString(4));
                book.setPrice(rs.getFloat(5));
                book.setEdition(rs.getInt(6));
                list.add(book);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public int deleteBook(int bookID) {
        int n = 0;
        try {
            Connection con = DBUtil.getDBConnection();
            String sql = "delete from books where bookID=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, bookID);
            n=ps.executeUpdate();
        }
        catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}
}
            
