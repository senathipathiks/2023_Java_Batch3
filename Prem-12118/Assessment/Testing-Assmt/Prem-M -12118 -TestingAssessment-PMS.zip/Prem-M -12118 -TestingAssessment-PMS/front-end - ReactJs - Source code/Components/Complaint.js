import React, { useState, useEffect } from "react";
import PetitionServices from "../Services/PetitionServices";

function Complaint() {
  const [complaints, setComplaints] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchComplaints();
  }, []);

  const fetchComplaints = async () => {
    try {
      const response = await PetitionServices.getAllComplaints();
      setComplaints(response.data);
    } catch (error) {
      console.error("Error fetching complaints:", error);
      setError("Error fetching complaints. Please try again.");
    }
  };

  const handleUpdateStatus = async (complaintId, newStatus) => {
    try {
      if (newStatus === "Resolved") {
        await PetitionServices.updateComplaintStatusToResolved(complaintId);
      } else if (newStatus === "Denied") {
        await PetitionServices.updateComplaintStatusToDenied(complaintId);
      }
      // Refresh complaints after updating status
      fetchComplaints();
    } catch (error) {
      console.error("Error updating complaint status:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Complaint Management</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <table className="table">
        <thead>
          <tr>
            <th>Complaint ID</th>
            <th>Description</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {complaints.map((complaint) => (
            <tr key={complaint.complaintId}>
              <td>{complaint.complaintId}</td>

              <td>{complaint.description}</td>
              <td>{complaint.status}</td>
              <td>
                <select
                  className="form-select"
                  onChange={(e) =>
                    handleUpdateStatus(complaint.complaintID, e.target.value)
                  }
                >
                  <option value="Pending">Pending</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Denied">Denied</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Complaint;
