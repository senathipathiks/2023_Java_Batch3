package com.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingAssessmentPmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingAssessmentPmsApplication.class, args);
	}

}
