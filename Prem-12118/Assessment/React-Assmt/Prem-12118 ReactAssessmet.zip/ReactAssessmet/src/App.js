import React, { useState, useEffect } from 'react';
import BugList from './components/BugList';
import BugForm from './components/BugForm';
import axios from 'axios';
import './App.css'

function App() {
  const [bugs, setBugs] = useState([]);

  useEffect(() => {
    // Fetch bugs from the server
    axios.get('http://localhost:8000/bugs')
      .then(response => setBugs(response.data))
      .catch(error => console.error('Error fetching bugs:', error));
  }, []);

  const handleBugAdded = (newBug) => {
    // Update the bugs state with the newly added bug
    setBugs(prevBugs => [...prevBugs, newBug]);
  };

  const handleDeleteBug = (id) => {
    // Update the bugs state by removing the deleted bug
    setBugs(prevBugs => prevBugs.filter(bug => bug.id !== id));
  };

  return (
    <div className="App">
      <h1>Bug Management System</h1>
      <BugList bugs={bugs} onDeleteBug={handleDeleteBug} />
      <BugForm onBugAdded={handleBugAdded} />
    </div>
  );
}

export default App;
