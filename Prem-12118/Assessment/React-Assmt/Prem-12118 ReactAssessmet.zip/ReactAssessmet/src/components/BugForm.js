import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import axios from 'axios';
import './BugForm.css'
 

const BugForm = ({ onBugAdded }) => {
  const { control, handleSubmit, reset, formState: { errors } } = useForm();

  const onSubmit = async (data) => {
    try {
      // Send the new bug to the server
      const response = await axios.post('http://localhost:8000/bugs', data);
      console.log('Form submitted with data:', data);
      console.log('Bug added successfully:', response.data);

      // Trigger the callback to inform the parent component (App.js) about the added bug
      onBugAdded(response.data);

      // Clear the form after submission
      reset();
    } catch (error) {
      console.error('Error adding bug:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <h2>Add New Bug</h2>

      <label>
        Bug Name:
        <Controller
          render={({ field }) => (
            <input type="text" {...field} />
          )}
          name="name"
          control={control}
          rules={{ required: 'Bug Name is required' }}
        />
        {errors.name && <p>{errors.name.message}</p>}
      </label>

      <label>
        Bug Description:
        <Controller
          render={({ field }) => (
            <textarea {...field} />
          )}
          name="description"
          control={control}
          rules={{ required: 'Bug Description is required' }}
        />
        {errors.description && <p>{errors.description.message}</p>}
      </label>

      <label>
        Identified By:
        <Controller
          render={({ field }) => (
            <input type="text" {...field} />
          )}
          name="identifiedBy"
          control={control}
          rules={{ required: 'Identified By is required' }}
        />
        {errors.identifiedBy && <p>{errors.identifiedBy.message}</p>}
      </label>

      <button type="submit">Add Bug</button>
    </form>
  );
};

export default BugForm;
