import React, { useState } from 'react';
import axios from 'axios';
import './BugList.css'

const BugList = ({ bugs, onDeleteBug }) => {
  const [deletingBugId, setDeletingBugId] = useState(null);

  const handleDelete = async (id) => {
    try {
      // Send a request to delete the bug
      await axios.delete(`http://localhost:8000/bugs/${id}`);
      onDeleteBug(id);
    } catch (error) {
      console.error('Error deleting bug:', error);
    } finally {
      // Reset the deletingBugId state after deleting
      setDeletingBugId(null);
    }
  };

  const showDeleteConfirmation = (id) => {
    // Set the deletingBugId to trigger the confirmation dialog
    setDeletingBugId(id);
  };

  return (
    <div>
      <h2>Bug List</h2>
      <ul>
        {bugs.map(bug => (
          <li key={bug.id}>
            <div>
              <strong>Bug Name:</strong> {bug.name}
            </div>
            <div>
              <strong>Description:</strong> {bug.description}
            </div>
            <div>
              <strong>Identified By:</strong> {bug.identifiedBy}
            </div>
            <button onClick={() => showDeleteConfirmation(bug.id)}>Delete Bug</button>
            {deletingBugId === bug.id && (
              <div>
                <p>Are you sure you want to delete this bug?</p>
                <button onClick={() => handleDelete(bug.id)}>Yes</button>
                <button onClick={() => setDeletingBugId(null)}>No</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BugList;
