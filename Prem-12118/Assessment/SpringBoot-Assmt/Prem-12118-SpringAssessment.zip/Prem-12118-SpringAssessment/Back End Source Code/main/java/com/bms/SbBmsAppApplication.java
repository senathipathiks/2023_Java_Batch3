package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbBmsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbBmsAppApplication.class, args);
	}

}
