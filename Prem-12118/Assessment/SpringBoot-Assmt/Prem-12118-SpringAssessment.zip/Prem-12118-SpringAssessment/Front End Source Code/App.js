import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./Navbar/Navbar";
import WelcomePage from "./Navbar/WelcomePage";
import BookTicket from "./Components/TicketComponents/BookTicket";
import EditTicket from "./Components/TicketComponents/EditTicket";
import ViewTicket from "./Components/TicketComponents/ViewTicket";
import AddUser from "./Components/UserComponents/AddUser";
import EditUser from "./Components/UserComponents/EditUser";
import ViewUser from "./Components/UserComponents/ViewUser";

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" element={<WelcomePage />} />
          <Route path="/AddUser" element={<AddUser />} />
          <Route path="/ViewUser" element={<ViewUser />} />
          <Route path="/EditUser/:userid" element={<EditUser />} />
          <Route path="/ViewTicket" element={<ViewTicket />} />
          <Route path="/BookTicket" element={<BookTicket />} />
          <Route path="/EditTicket/:tid" element={<EditTicket />} />
          <Route path="/WelcomePage" element={<WelcomePage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
