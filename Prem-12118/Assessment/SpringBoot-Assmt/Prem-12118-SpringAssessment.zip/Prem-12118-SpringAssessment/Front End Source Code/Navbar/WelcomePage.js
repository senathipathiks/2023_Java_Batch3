import React from "react";

const WelcomePage = () => {
  return (
    <div className="welcome-page d-flex flex-column min-vh-100 bg-light overflow-hidden">
      <header className="header container py-5 text-center">
        <div className="d-flex justify-content-center align-items-center mb-3">
          <button className="btn btn-primary me-3">New User</button>
          <p className="instruction mb-0 font-weight-bold">
            <bold>
              New User? Click "New User" to register and remember your User ID
              for booking tickets.
            </bold>
          </p>
        </div>
        <h1 className="mb-0">Bus Ticket Booking Management System</h1>
        <p className="subheading lead mb-4">
          Organize, book, and manage your bus tickets hassle-free.
        </p>
      </header>

      <section className="features container py-3">
        <h2 className="mb-5 text-center">Why Choose Us?</h2>
        <div className="row row-cols-1 row-cols-md-3 g-4">
          <div className="col feature text-center">
            <i className="bi bi-calendar2-check-fill display-4 text-primary mb-3"></i>
            <h3>Effortless Booking</h3>
            <p>
              Book your bus tickets seamlessly with our user-friendly platform.
            </p>
          </div>
          <div className="col feature text-center">
            <i className="bi bi-search display-4 text-primary mb-3"></i>
            <h3>Quick Search</h3>
            <p>
              Find and select your desired routes quickly using our advanced
              search feature.
            </p>
          </div>
          <div className="col feature text-center">
            <i className="bi bi-person-lines-fill display-4 text-primary mb-3"></i>
            <h3>24/7 Customer Support</h3>
            <p>
              Our dedicated support team is available round the clock to assist
              you with any inquiries.
            </p>
          </div>
        </div>
      </section>

      <section className="call-to-action container py-3 text-center">
        <a href="/book-ticket" className="btn btn-primary me-3">
          Book Now
        </a>
        <a href="#" className="btn btn-outline-secondary">
          Learn More
        </a>
      </section>
    </div>
  );
};

export default WelcomePage;
