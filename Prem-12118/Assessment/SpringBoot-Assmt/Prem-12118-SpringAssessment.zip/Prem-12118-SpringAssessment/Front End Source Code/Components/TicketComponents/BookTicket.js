import React, { useState, useEffect } from "react";
import TicketService from "../../Services/TicketService";
import UserService from "../../Services/UserService";

function BookTicket() {
  const [data, setData] = useState({
    boardingPoint: "",
    departurePoint: "",
    user: {
      userId: "",
    },
  });
  const [userList, setUserList] = useState([]);

  useEffect(() => {
    populateUsers();
  }, []);

  const populateUsers = async () => {
    try {
      const response = await UserService.getAllUsersId();
      setUserList(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await TicketService.createTicket(data);
      alert("Ticket booked successfully");
      // Clear form fields after successful booking
      setData({
        boardingPoint: "",
        departurePoint: "",
        user: { userId: "" },
      });
    } catch (error) {
      console.error("Error booking ticket:", error);
    }
  };

  const handleUserChange = (e) => {
    const selectedUserId = e.target.value;
    setData({
      ...data,
      user: { userId: selectedUserId },
    });
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <form onSubmit={handleSubmit} className="card p-4">
            <div className="card-body">
              <h4 className="card-title text-center mb-4">Book Ticket</h4>
              <div className="mb-3">
                <label htmlFor="boardingPoint" className="form-label">
                  Boarding Point:
                </label>
                <input
                  type="text"
                  name="boardingPoint"
                  id="boardingPoint"
                  placeholder="Enter boarding point"
                  value={data.boardingPoint}
                  onChange={(e) =>
                    setData({ ...data, boardingPoint: e.target.value })
                  }
                  className="form-control"
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="departurePoint" className="form-label">
                  Departure Point:
                </label>
                <input
                  type="text"
                  name="departurePoint"
                  id="departurePoint"
                  placeholder="Enter departure point"
                  value={data.departurePoint}
                  onChange={(e) =>
                    setData({ ...data, departurePoint: e.target.value })
                  }
                  className="form-control"
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="userId" className="form-label">
                  User:
                </label>
                <select
                  name="userId"
                  id="userId"
                  className="form-select"
                  value={data.user.userId}
                  onChange={handleUserChange}
                  required
                >
                  <option value="">Select User</option>
                  {userList.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
              <button type="submit" className="btn btn-primary btn-block">
                Book Ticket
              </button>
            </div>
          </form>
        </div>
      </div>
      <p className="text-center text-muted mt-5">
        &copy;2024 Your Company. All rights reserved.
      </p>
    </div>
  );
}

export default BookTicket;
