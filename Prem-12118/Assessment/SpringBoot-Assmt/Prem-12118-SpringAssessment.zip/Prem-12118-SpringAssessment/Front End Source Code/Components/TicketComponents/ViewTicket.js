import React, { useState, useEffect } from "react";
import TicketService from "../../Services/TicketService";
import { Link } from "react-router-dom";

function ViewTicket() {
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    try {
      const response = await TicketService.getAllTickets();
      console.log(response.data);
      setTickets(response.data);
    } catch (error) {
      console.error("Error fetching ticket data:", error);
    }
  };

  const handleDelete = async (ticketId) => {
    try {
      await TicketService.deleteTicket(ticketId);
      alert("Ticket deleted successfully");
      loadTickets();
    } catch (error) {
      console.error("Error deleting ticket:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>View Tickets</h2>
      <table className="table table-bordered table-hover">
        <thead>
          <tr>
            <th scope="col">Ticket ID</th>
            <th scope="col">Boarding Point</th>
            <th scope="col">Departure Point</th>
            <th scope="col">User ID</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          {tickets.map((ticket) => (
            <tr key={ticket.ticketId}>
              <td>{ticket.ticketId}</td>
              <td>{ticket.boardingPoint}</td>
              <td>{ticket.departurePoint}</td>
              <td>{ticket.user ? ticket.user.userId : "No User"}</td>
              <td>
                <Link
                  to={`/EditTicket/${ticket.ticketId}`} // Pass ticketId as a parameter
                  className="btn btn-warning btn-sm me-2"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDelete(ticket.ticketId)}
                  className="btn btn-danger btn-sm"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-end">
        <Link to="/BookTicket" className="btn btn-primary">
          Add Ticket
        </Link>
      </div>
    </div>
  );
}

export default ViewTicket;
