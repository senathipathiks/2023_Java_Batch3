import React, { useState, useEffect } from "react";
import TicketService from "../../Services/TicketService";
import UserService from "../../Services/UserService";
import { useNavigate, useParams } from "react-router-dom";

function EditTicket() {
  const { tid } = useParams();
  const navigate = useNavigate();

  const [ticket, setTicket] = useState({
    boardingPoint: "",
    departurePoint: "",
    userId: "", // Add userId property
  });

  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadTicketById(tid);
    fetchUsers();
  }, [tid]);

  const loadTicketById = async (tid) => {
    try {
      const response = await TicketService.getTicketById(tid);
      setTicket({ ...response.data }); // Update state with response data
    } catch (error) {
      console.error("Error loading ticket:", error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await UserService.getAllUsersId();
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTicket({ ...ticket, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await TicketService.updateTicket(tid, ticket);
      alert("Ticket updated successfully");
      navigate("/ViewTicket");
    } catch (error) {
      console.error("Error updating ticket:", error);
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <h1>Edit Ticket</h1>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="boardingPoint" className="form-label">
                Boarding Point:
              </label>
              <input
                type="text"
                name="boardingPoint"
                id="boardingPoint"
                value={ticket.boardingPoint}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="departurePoint" className="form-label">
                Departure Point:
              </label>
              <input
                type="text"
                name="departurePoint"
                id="departurePoint"
                value={ticket.departurePoint}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="userId" className="form-label">
                User:
              </label>
              <select
                name="userId"
                id="userId"
                value={ticket.userId}
                onChange={handleChange}
                className="form-select"
                required
              >
                <option value="">Choose a User</option>
                {users.map((user) => (
                  <option key={user.userId} value={user.userId}>
                    {user.userId}
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn btn-primary">
              Update Ticket
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default EditTicket;
