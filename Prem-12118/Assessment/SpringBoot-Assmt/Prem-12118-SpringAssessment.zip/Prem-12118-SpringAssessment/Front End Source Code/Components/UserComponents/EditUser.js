import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import UserService from "../../Services/UserService";

function EditUser() {
  const { id } = useParams();
  const [user, setUser] = useState({
    userName: "",
    userMobNo: "",
    travelTime: "",
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const response = await UserService.getUserById(id);
      setUser(response.data);
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await UserService.updateUser(id, user);
      alert("User updated successfully");
      // Redirect to View User page after successful update
      window.location = "/view-user";
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  return (
    <div className="container my-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <h2 className="text-center mb-4">Edit User</h2>
          <form onSubmit={handleSubmit} className="card p-4 shadow-sm">
            <div className="mb-3">
              <label htmlFor="userName" className="form-label">
                User Name
              </label>
              <input
                type="text"
                className="form-control"
                id="userName"
                name="userName"
                value={user.userName}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="userMobNo" className="form-label">
                Mobile Number
              </label>
              <input
                type="text"
                className="form-control"
                id="userMobNo"
                name="userMobNo"
                value={user.userMobNo}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="travelTime" className="form-label">
                Travel Time
              </label>
              <input
                type="text"
                className="form-control"
                id="travelTime"
                name="travelTime"
                value={user.travelTime}
                onChange={handleChange}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Update User
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default EditUser;
