import React, { useState, useEffect } from "react";
import UserService from "../../Services/UserService";
import { Link } from "react-router-dom";

function ViewUser() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await UserService.getAllUsers();
      console.log(response.data);
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const handleDelete = async (userId) => {
    try {
      await UserService.deleteUser(userId);
      alert("User deleted successfully");
      loadUsers();
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Users</h2>
      <table className="table table-bordered table-hover">
        <thead>
          <tr>
            <th scope="col">User ID</th>
            <th scope="col">User Name</th>
            <th scope="col">Mobile Number</th>
            <th scope="col">Travel Time</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.userId}>
              <td>{user.userId}</td>
              <td>{user.userName}</td>
              <td>{user.userMobNo}</td>
              <td>{user.travelTime}</td>
              <td>
                <Link
                  to={`/EditUser/${user.userId}`}
                  className="btn btn-warning btn-sm me-2"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDelete(user.userId)}
                  className="btn btn-danger btn-sm"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-end">
        <Link to="/AddUser" className="btn btn-primary">
          Add User
        </Link>
      </div>
    </div>
  );
}

export default ViewUser;
