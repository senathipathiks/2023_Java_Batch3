import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import UserService from "../../Services/UserService";

function AddUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    userName: "",
    userMobNo: "",
    travelTime: "",
  });

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onPost = (e) => {
    e.preventDefault();
    UserService.createUser(user)
      .then(() => {
        alert("User added successfully!");
        navigate("/");
      })
      .catch((error) => {
        console.error("Error adding user:", error);
        alert("Error adding user. Please try again.");
      });
  };

  return (
    <div className="container my-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <h4 className="text-center mb-4">
            <bold>New Users ? Register Below.</bold>
          </h4>
          <form onSubmit={(e) => onPost(e)} className="card p-4 shadow-sm">
            <div className="mb-3">
              <label htmlFor="userName" className="form-label">
                User Name:
              </label>
              <input
                type="text"
                className="form-control"
                id="userName"
                name="userName"
                placeholder="Enter user name"
                value={user.userName}
                onChange={(e) => onInputChange(e)}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="userMobNo" className="form-label">
                Mobile Number:
              </label>
              <input
                type="text"
                className="form-control"
                id="userMobNo"
                name="userMobNo"
                placeholder="Enter mobile number"
                value={user.userMobNo}
                onChange={(e) => onInputChange(e)}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="travelTime" className="form-label">
                Travel Time:
              </label>
              <input
                type="text"
                className="form-control"
                id="travelTime"
                name="travelTime"
                placeholder="Enter travel time"
                value={user.travelTime}
                onChange={(e) => onInputChange(e)}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Add User
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default AddUser;
