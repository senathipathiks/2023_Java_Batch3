import axios from "axios";

class UserService {
  getAllUsers() {
    return axios.get("http://localhost:1234/GetAllUsers");
  }

  createUser(user) {
    return axios.post("http://localhost:1234/CreateUser", user);
  }

  getUserById(userId) {
    return axios.get(`http://localhost:1234/GetUserById/${userId}`);
  }

  updateUser(userId, userData) {
    return axios.put(`http://localhost:1234/UpdateUser/${userId}`, userData);
  }

  deleteUser(userId) {
    return axios.delete(`http://localhost:1234/DeleteUserById/${userId}`);
  }

  getAllUsersId() {
    return axios.get("http://localhost:1234/GetAllUsersId");
  }
}

export default new UserService();
