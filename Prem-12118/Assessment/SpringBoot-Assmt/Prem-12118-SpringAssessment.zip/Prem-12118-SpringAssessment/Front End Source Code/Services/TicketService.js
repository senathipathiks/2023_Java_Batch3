import axios from "axios";

const TicketService = {
  getAllTickets: () => {
    return axios.get("http://localhost:1234/GetAllTickets");
  },

  createTicket: (ticket) => {
    return axios.post("http://localhost:1234/CreateTicket", ticket);
  },

  getTicketById: (ticketId) => {
    return axios.get(`http://localhost:1234/GetTicketById/${ticketId}`);
  },

  updateTicket: (ticketId, ticketData) => {
    return axios.put(
      `http://localhost:1234/UpdateTicket/${ticketId}`,
      ticketData
    );
  },

  deleteTicket: (ticketId) => {
    return axios.delete(`http://localhost:1234/DeleteTicketById/${ticketId}`);
  },

  getTicketId: () => {
    return axios.get("http://localhost:1234/GetTicketId");
  },
};

export default TicketService;
