package com.sms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.sms.bean.Student;
import com.sms.util.Db_util;

public class StudentDAO {
	
	public static int insertStudent(Student stud) {
		int n=0;
		
		try {
			Connection c=Db_util.getDBConnection();
			
			String sql="insert into student values(?,?,?)";
			PreparedStatement prs=c.prepareStatement(sql);
			
			prs.setInt(1,stud.getSid());
			prs.setString(2,stud.getSname());
			prs.setString(3,stud.getCity());
			n=prs.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}
	
	public static int deleteStudent(int id) {
		int n=0;
		try {
			Connection c1=Db_util.getDBConnection();
			
			String sql1="DELETE FROM `student` WHERE (sid = ?)";
			PreparedStatement prs1=c1.prepareStatement(sql1);
			
			prs1.setInt(1, id);
			n=prs1.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}
	
	public static int updateStudent(Student stud) {	//updation
		int n=0;
		try {
			Connection c2=Db_util.getDBConnection();
			
			String sql2="UPDATE `student_management_sys`.`student` SET `sname` =?, `city` =?  WHERE (`sid` = ?);";
			
			PreparedStatement prs2=c2.prepareStatement(sql2);
			
			
			prs2.setString(1,stud.getSname());
			prs2.setString(2, stud.getCity());
			prs2.setInt(3, stud.getSid());
			n=prs2.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}
	
	public static int findStudent(int id) {
		int n=0;
		try {
			Connection c3=Db_util.getDBConnection();
			
			String sql3="SELECT * from student where sid=?";
			
			PreparedStatement prs3=c3.prepareStatement(sql3);
			
			prs3.setInt(1, id);
			
			ResultSet rs=prs3.executeQuery();
			while(rs.next()) {
				System.out.println("Id : "+rs.getInt(1)+"\nName : "+rs.getString(2)+"\nCity : "+rs.getString(3));
				n++;
			}
		
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Enter valid detail");
		}
		return n;
	}
	
	public static int findallStudent() {
		int n=0;
		
		try {
			Connection c4=Db_util.getDBConnection();
			
			String sql4="SELECT * from student";
			
			PreparedStatement psr4=c4.prepareStatement(sql4);
			
			ResultSet rs=psr4.executeQuery();
			
			while (rs.next()) {
				System.out.println("Id : "+rs.getInt(1)+"\nName : "+rs.getString(2)+"\nCity : "+rs.getString(3));

			}
			n=1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;
	}

}
