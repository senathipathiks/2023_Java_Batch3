package com.sms.main;

import java.util.Scanner;

import com.sms.bean.Student;
import com.sms.dao.StudentDAO;

public class SmsMain {
	static Scanner sc=new Scanner(System.in);
	
	public static int menu() {	//method for entering choice to perform option
		
		System.out.println("1.Insert\n2.Delete\n3.Update\n4.Find\n5.FindAll\n6.Exit");
		System.out.println("Enter your option");
		int opt=sc.nextInt();
		return opt;
	}
	
	public static Student insertStudent() {
		System.out.println("Enter student id,Student name,Student city");
		
		return new Student(sc.nextInt(),sc.next(),sc.next());
	}
	
	public static int deleteStudent() {
		System.out.println("Enter student id to delete");
		return (sc.nextInt());
		
	}
	
	public static Student updateStudent() {
		System.out.println("Enter student id,student name,student ");
		return new  Student(sc.nextInt(),sc.next(),sc.next());
	}
	
	public static int findStudent() {
		System.out.println("Enter student id to get the details");
		return (sc.nextInt());
	}
	
//	public static int findallStudent() {   	it is not required because it is not neccessary to get input from user 
					//to show the table details
//		System.out.println("Details persent in the student table");
//		return (sc.nextInt());
//	}
	
	//main method
	public static void main(String[] args) {
	String  msg=" ";
	int n;
	StudentDAO dao=new StudentDAO();
	
	do {
        switch(menu()) {
        case 1:
            Student st1=insertStudent();
            n=dao.insertStudent(st1);
            if(n==1) {
                System.out.println("\nRecord inserted Sucessfully");
            }
            else
            	System.out.println("\nRecord insertion failed");
            break;
            
        case 2:
        	int st2=deleteStudent();
        	n=dao.deleteStudent(st2);
        	if(n==1) {
        		System.out.println("\nRecord deleted successfully");
        	}
        	else
        		System.out.println("\nRecord deletion failed");
        	break;
        	
        case 3:
        	Student st3=updateStudent();
        	n=dao.updateStudent(st3);
        	if(n==1) {
        		System.out.println("\nRecord updated successfully");
        	}
        	else
        		System.out.println("\nRecord updation failed");
        	
        	break;
        	
        case 4:
        	int st4=findStudent();
        	n=dao.findStudent(st4);
        	
        	if(n>0) {
        		System.out.println("\nRecord accessed successfully");
        	}
        	else
        		System.out.println("\nRecord access failed");
        	
        	break;
        	
        case 5:
//        	int st5=findallStudent();
        	n=dao.findallStudent();
        	
        	if(n==1) {
        		System.out.println("\nShowing of all record successfull ");
        	}
        	else
        		System.out.println("\nShowing of all record failed");
	}
        
        System.out.println("\nDo you want to continue \n1.Yes\n2.No");
        msg=sc.next();
        
	} while(msg.equals("Yes")||msg.equals("yes"));
	
	
	System.out.println("Thank you !");
	
	
	}		
}
