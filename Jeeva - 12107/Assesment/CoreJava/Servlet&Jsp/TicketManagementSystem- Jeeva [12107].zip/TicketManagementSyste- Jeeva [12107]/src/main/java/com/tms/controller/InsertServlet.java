package com.tms.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import com.tms.bean.Ticket;
import com.tms.dao.TicketDao;

public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int n=0;

		TicketDao dao=new TicketDao();
		PrintWriter out=response.getWriter();

		String action=request.getParameter("button");

		if(action.equals("Insert")) { 

			if(request.getParameter("ticketId")=="" || request.getParameter("category")=="" || request.getParameter("subject")=="" ) {
				response.sendRedirect("Empty.jsp?action=Insert");

			}
			else {
				int id=Integer.parseInt(request.getParameter("ticketId"));
				String category=request.getParameter("category");
				String subject=request.getParameter("subject");
				String descr=request.getParameter("descr");
				String priority=request.getParameter("priority");
				String raisedBy=request.getParameter("raisedBy");
				String assignedTo=request.getParameter("assignedTo");
				String status=request.getParameter("status");
				Ticket tic=new Ticket(id,category,subject,descr,priority,raisedBy,assignedTo,status);
				n=dao.insertTicket(tic);
				if(n==1) {
					response.sendRedirect("AllSuccess.jsp?action=Insert");
				}else {
					response.sendRedirect("AllFailure.jsp?action=Insert");
				}
			}
		}

		else if(action.equals("Find")) {
			if(request.getParameter("ticketId")=="" || request.getParameter("category")=="" || request.getParameter("subject")=="" ) {
				response.sendRedirect("Empty.jsp?action=Find");

			}else {		
				int id=Integer.parseInt(request.getParameter("ticketId"));
				Ticket tic=new Ticket();
				tic = TicketDao.findTicket(id);
				if(tic!=null) {
					request.getSession().setAttribute("bean", tic);
					response.sendRedirect("AllSuccess.jsp?action=Find");				
				}
				else {
					response.sendRedirect("AllFailure.jsp?action=Find");
				}
			}}
		else if(action.equals("FindAll")) {

			Ticket stu=new Ticket();

			LinkedList<Ticket> list=new LinkedList<Ticket>();
			list=dao.findAllTicket();

			if(list.size()>0) {
				request.getSession().setAttribute("bean", list);
				response.sendRedirect("AllSuccess.jsp?action=FindAll");

			}else {
				response.sendRedirect("AllFailure.jsp?action=FindAll");
			}

		}


		else if(action.equals("Delete")) {
			if(request.getParameter("ticketId")=="") {
				response.sendRedirect("Empty.jsp?action=Delete");

			}else {
				RequestDispatcher rd=request.getRequestDispatcher("delete.jsp");

				int id=Integer.parseInt(request.getParameter("ticketId"));				int del =dao.deleteTicket(id);
				if(del==1) {				

					response.sendRedirect("AllSuccess.jsp?action=Delete");
				}
				else {
					response.sendRedirect("AllFailure.jsp?action=Delete");

				}
			}
		}

		else if(action.equals("Update")) {
			if(request.getParameter("TicketId")=="" || request.getParameter("category")=="" || request.getParameter("subject")==""
					||request.getParameter("descr")==""||request.getParameter("priority")==""||request.getParameter("raisedBy")==""||request.getParameter("assignedTo")==""|| request.getParameter("status")=="") {
				response.sendRedirect("Empty.jsp?action=Update");

			}else {
				RequestDispatcher r=request.getRequestDispatcher("update.jsp");

				int id=Integer.parseInt(request.getParameter("ticketId"));
				String category=request.getParameter("category");
				String subject=request.getParameter("subject");
				String descr=request.getParameter("descr");
				String priority=request.getParameter("priority");
				String raisedBy=request.getParameter("raisedBy");
				String assignedTo=request.getParameter("assignedTo");
				String status=request.getParameter("status");

				Ticket stud=new Ticket(id,category,subject,descr,priority,raisedBy,assignedTo,status);
				n=dao.updateTicket(stud);
				if(n==1) {
					response.sendRedirect("AllSuccess.jsp?action=Update");
				}else {

					response.sendRedirect("AllFailure.jsp?action=Update");

				}
			}
		}
		else if(action.equals("DeleteAll")) {

			int del =dao.deleteAllTicket();
			if(del==1) {				

				response.sendRedirect("AllSuccess.jsp?action=DeleteAll");
			}
			else {
				response.sendRedirect("AllFailure.jsp?action=DeleteAll");

			}}}}