package com.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Scanner;

import com.tms.bean.Ticket;
import com.tms.util.DBUtil;


public class TicketDao {
	public int insertTicket(Ticket tic)  {
		Scanner sc=new Scanner(System.in);
			int n=0;
			try {
			Connection con=DBUtil.getDBConnection();
			String sql="insert into tickettable values (?,?,?,?,?,?,?,?)";
			PreparedStatement pt=con.prepareStatement(sql);
			pt.setInt(1, tic.getTicketId());			
			pt.setString(2,tic.getCategory());
			pt.setString(3, tic.getSubject());
			pt.setString(4, tic.getDescr());
			pt.setString(5, tic.getPriority());
			pt.setString(6, tic.getRaisedBy());
			pt.setString(7, tic.getAssignedTo());
			pt.setString(8, tic.getStatus());
			n=pt.executeUpdate();
			
			}
			catch(Exception e) {
				System.out.println(e);
			}
			return n;
		}

		

		public int deleteTicket(int id) {
			int n=0;
			try {
			Connection con=DBUtil.getDBConnection();
			String query="delete from tickettable where ticketId=?";
			PreparedStatement pt=con.prepareStatement(query);
			pt.setInt(1,id);
			n=pt.executeUpdate();
			}catch(Exception e) {
				System.out.println(e);
			}
			return n;
		}
		



		public int updateTicket(Ticket tic) {
			int n=0;
			try {
				Connection con=DBUtil.getDBConnection();
				String query="Update tickettable set category=?,subject=?,descr=?,priority=?,raisedBy=?,assignedTo=?,status=? where ticketId=?";
				PreparedStatement pt=con.prepareStatement(query);
				
				pt.setString(1, tic.getCategory());
				pt.setString(2,tic.getCategory());
				pt.setString(3, tic.getSubject());
				pt.setString(4, tic.getDescr());
				pt.setString(5, tic.getPriority());
				pt.setString(6, tic.getRaisedBy());
				pt.setString(7, tic.getAssignedTo());
				pt.setInt(8, tic.getTicketId());			
				n=pt.executeUpdate();
				}catch(Exception e) {
					System.out.println(e);
				}
				return n;
			
		}


		public LinkedList<Ticket> findAllTicket() {
			
			ResultSet rs;
			LinkedList<Ticket>  list=new LinkedList<Ticket>();
			try {
			Connection con=DBUtil.getDBConnection();
			 String query = "select * from tickettable";
			 PreparedStatement st=con.prepareStatement(query);
			 rs=st.executeQuery();
		    while(rs.next()) {
		    	Ticket s=new Ticket();
		    	s.setTicketId(rs.getInt(1));
		    	s.setCategory(rs.getString(2));
		    	s.setSubject(rs.getString(3));
		    	s.setDescr(rs.getString(4));
		    	s.setPriority(rs.getString(5));
		    	s.setRaisedBy(rs.getString(6));
		    	s.setAssignedTo(rs.getString(7));
		    	s.setStatus(rs.getString(8));
		    	
		    	list.add(s);
		    }
			
			}catch(Exception e) {
				System.out.println(e);
			}
			
			return list;
		}
		
		
		public static Ticket findTicket(int id) {
			
			Ticket s=null;
			
			  try {
		             Connection con=DBUtil.getDBConnection();
		             String sql="select * from tickettable where ticketId=?";
		            PreparedStatement ps = con.prepareStatement(sql);
		             ps.setInt(1, id);
		             ResultSet rs=ps.executeQuery();
		             if(rs.next()) {
		            	 s=new Ticket();
		            	 s.setTicketId(rs.getInt(1));
		 		    	s.setCategory(rs.getString(2));
		 		    	s.setSubject(rs.getString(3));
		 		    	s.setDescr(rs.getString(4));
		 		    	s.setPriority(rs.getString(5));
		 		    	s.setRaisedBy(rs.getString(6));
		 		    	s.setAssignedTo(rs.getString(7));
		 		    	s.setStatus(rs.getString(8));
		 
		             }
		        } catch (SQLException e) {
		            
		            System.out.println(e);
		        }
		        return s;
		         	
		}



		public int deleteAllTicket() {
			int n=0;
			try {
			Connection con=DBUtil.getDBConnection();
			String query="truncate table tickettable";
			PreparedStatement pt=con.prepareStatement(query);
			n=pt.executeUpdate();
			}catch(Exception e) {
				System.out.println(e);
			}
			return n;
		}
		

	}
