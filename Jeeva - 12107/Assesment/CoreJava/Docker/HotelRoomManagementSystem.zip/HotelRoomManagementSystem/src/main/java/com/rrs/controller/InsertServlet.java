package com.rrs.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import com.rrs.bean.Hotel;
import com.rrs.dao.HotelDao;


public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int n=0;

		HotelDao dao=new HotelDao();
		PrintWriter out=response.getWriter();

		String action=request.getParameter("button");

		if(action.equals("Insert")) { 

			if(request.getParameter("reservationId")=="" || request.getParameter("name")=="" || request.getParameter("address")=="" ) {
				response.sendRedirect("Empty.jsp?action=Insert");

			}
			else {
				int id=Integer.parseInt(request.getParameter("reservationId"));
				String name=request.getParameter("name");
				String address=request.getParameter("address");
				
				Hotel tic=new Hotel(id,name,address);
				n=dao.insertHotel(tic);
				if(n==1) {
					response.sendRedirect("AllSuccess.jsp?action=Insert");
				}else {
					response.sendRedirect("AllFailure.jsp?action=Insert");
				}
			}
		}

		else if(action.equals("Find")) {
			if(request.getParameter("reservationId")=="" || request.getParameter("name")=="" || request.getParameter("address")=="" ) {
				response.sendRedirect("Empty.jsp?action=Find");

			}else {		
				int id=Integer.parseInt(request.getParameter("reservationId"));
				Hotel h=new Hotel();
				h = HotelDao.findHotel(id);
				if(h!=null) {
					request.getSession().setAttribute("bean", h);
					response.sendRedirect("AllSuccess.jsp?action=Find");				
				}
				else {
					response.sendRedirect("AllFailure.jsp?action=Find");
				}
			}}
		else if(action.equals("FindAll")) {

			Hotel stu=new Hotel();

			LinkedList<Hotel> list=new LinkedList<Hotel>();
			list=dao.findAllHotel();

			if(list.size()>0) {
				request.getSession().setAttribute("bean", list);
				response.sendRedirect("AllSuccess.jsp?action=FindAll");

			}else {
				response.sendRedirect("AllFailure.jsp?action=FindAll");
			}

		}


		else if(action.equals("Delete")) {
			if(request.getParameter("reservationId")=="") {
				response.sendRedirect("Empty.jsp?action=Delete");

			}else {
				RequestDispatcher rd=request.getRequestDispatcher("delete.jsp");

				int id=Integer.parseInt(request.getParameter("reservationId"));
				int del =dao.deleteHotel(id);
				if(del==1) {				

					response.sendRedirect("AllSuccess.jsp?action=Delete");
				}
				else {
					response.sendRedirect("AllFailure.jsp?action=Delete");

				}
			}
		}

		else if(action.equals("Update")) {
			if(request.getParameter("reservationId")=="" || request.getParameter("name")=="" || request.getParameter("address")=="") {
				response.sendRedirect("Empty.jsp?action=Update");

			}else {
				RequestDispatcher r=request.getRequestDispatcher("update.jsp");

				int id1=Integer.parseInt(request.getParameter("reservationId"));
				String name1=request.getParameter("name");
				String address1=request.getParameter("address");
				
				Hotel stud=new Hotel(id1,name1,address1);
				n=dao.updateHotel(stud);
				if(n==1) {
					response.sendRedirect("AllSuccess.jsp?action=Update");
				}else {

					response.sendRedirect("AllFailure.jsp?action=Update");

				}
			}
		}
	}
}
		