package com.rrs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Scanner;

import com.rrs.bean.Hotel;
import com.rrs.util.DBUtil;


public class HotelDao {

	public int insertHotel(Hotel h)  {
		Scanner sc=new Scanner(System.in);
			int n=0;
			try {
			Connection con=DBUtil.getDBConnection();
			String sql="insert into hotels values (?,?,?)";
			PreparedStatement pt=con.prepareStatement(sql);
			pt.setInt(1,h.getReservationId() );			
			pt.setString(2,h.getName());
			pt.setString(3, h.getAddress());
			
			n=pt.executeUpdate();
			
			}
			catch(Exception e) {
				System.out.println(e);
			}
			return n;
		}

		

		public int deleteHotel(int id) {
			int n=0;
			try {
			Connection con=DBUtil.getDBConnection();
			String query="delete from hotels where reservationId=?";
			PreparedStatement pt=con.prepareStatement(query);
			pt.setInt(1,id);
			n=pt.executeUpdate();
			}catch(Exception e) {
				System.out.println(e);
			}
			return n;
		}
		



		public int updateHotel(Hotel h) {
			int n=0;
			try {
				Connection con=DBUtil.getDBConnection();
				String query="Update hotels set name=?,address=? where reservationId=?";
				PreparedStatement pt=con.prepareStatement(query);
				
				pt.setString(1, h.getName());
				pt.setString(2,h.getAddress());
				pt.setInt(3, h.getReservationId());
				n=pt.executeUpdate();
				}catch(Exception e) {
					System.out.println(e);
				}
				return n;
			
		}


		public LinkedList<Hotel> findAllHotel() {
			
			ResultSet rs;
			LinkedList<Hotel>  list=new LinkedList<Hotel>();
			try {
			Connection con=DBUtil.getDBConnection();
			 String query = "select * from hotels";
			 PreparedStatement st=con.prepareStatement(query);
			 rs=st.executeQuery();
		    while(rs.next()) {
		    	Hotel s=new Hotel();
		    	s.setReservationId(rs.getInt(1));
		    	s.setName(rs.getString(2));
		    	s.setAddress(rs.getString(3));	    	
		    	list.add(s);
		    }
			
			}catch(Exception e) {
				System.out.println(e);
			}
			
			return list;
		}
		
		
		public static Hotel findHotel(int id) {
			
			Hotel s=null;
			
			  try {
		             Connection con=DBUtil.getDBConnection();
		             String sql="select * from hotels where reservationId=?";
		            PreparedStatement ps = con.prepareStatement(sql);
		             ps.setInt(1, id);
		             ResultSet rs=ps.executeQuery();
		             if(rs.next()) {
		            	 s=new Hotel();		 		    	
		 		    	s.setReservationId(rs.getInt(1));
		 		    	s.setName(rs.getString(2));
		 		    	s.setAddress(rs.getString(3));
		 
		             }
		        } catch (SQLException e) {
		            
		            System.out.println(e);
		        }
		        return s;
		         	
		}



}
