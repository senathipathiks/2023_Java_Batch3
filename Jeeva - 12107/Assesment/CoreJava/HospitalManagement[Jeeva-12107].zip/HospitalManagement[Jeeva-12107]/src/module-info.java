/**
 * 
 */
/**
 * 
 */
module HospitalMs {
	requires java.sql;
}