package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.hms.bean.Hospital;
import com.hms.util.DbHmsUtil;





public class HospitalDao {
	Scanner s=new Scanner(System.in);
	public int insertHospital(Hospital h1) {
		
		int n=0;
		try {
		Connection con=DbHmsUtil.getDBConnection();
		String query="insert into hospital values (?,?,?,?,?,?,?)";
		PreparedStatement pt=con.prepareStatement(query);
		pt.setInt(1, h1.getHospId());
		pt.setString(2,h1.getHospName());
		pt.setString(3,h1.getHospAddress());
		pt.setString(4,h1.getHospPhoneNo());
		pt.setString(5,h1.getHospEmail());
		pt.setFloat(6,h1.getHospRating());
		pt.setInt(7,h1.getHospNoOfBeds());
		n=pt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return n;
		
	}
	
	public int deleteHospital(int id) {
		int n=0;
		try {
		Connection con=DbHmsUtil.getDBConnection();
		String query="delete from hospital where hospId=?";
		PreparedStatement pt=con.prepareStatement(query);
		pt.setInt(1,id);
		n=pt.executeUpdate();
		}catch(Exception e) {
			System.out.println(e);
		}
		return n;
	}
	
	public int updateAllHospital(Hospital h2) {
		int n=0;
		try {
			Connection con=DbHmsUtil.getDBConnection();
String query="Update hospital set hospName=?,hospAddress=?,hospPhoneNo=?,hospEmail=?,hospRating=?,hospNoOfBeds=? where hospId=?";
			PreparedStatement pt=con.prepareStatement(query);
			pt.setString(1, h2.getHospName());	
			pt.setString(2, h2.getHospAddress());	
			pt.setString(3, h2.getHospPhoneNo());	
			pt.setString(4, h2.getHospEmail());	
			pt.setFloat(5, h2.getHospRating());	
			pt.setInt(6, h2.getHospNoOfBeds());	
			pt.setInt(7, h2.getHospId());	
			n=pt.executeUpdate();
			}catch(Exception e) {
				System.out.println(e);
			}
			return n;
	}

	public int updateParticularColumn(String h2) {
		int n=0;
		System.out.println("Which Id You Need To Change The "+h2);
		int id=s.nextInt();
		
		try {
			Connection con=DbHmsUtil.getDBConnection();
			String query="Update hospital set hospEmail=? where hospId=?";
			PreparedStatement pt=con.prepareStatement(query);
			pt.setString(1, h2);		
			pt.setInt(2, id);	
			n=pt.executeUpdate();
			}catch(Exception e) {
				System.out.println(e);
			}
			return n;
	}


	public int findHospital(int find) {
		int n=0;
		  try {
	             Connection con=DbHmsUtil.getDBConnection();
	             String sql="select * from hospital where hospId=?";
	            PreparedStatement ps = con.prepareStatement(sql);
	             ps.setInt(1, find);
	             ResultSet rs=ps.executeQuery();
	             while(rs.next()) {
	            	 System.out.println("HospitalId : "+rs.getInt(1)+"\nHospitalName : "+rs.getString(2)+"\nHospitalAddress : "+rs.getString(3)+"\nHospitalPhoneNo : "+rs.getString(4)+"\nHospitalEmail : "+rs.getString(5)+"\nHospitalRating : "+rs.getFloat(6)+"\nNoOfBeds : "+rs.getInt(7));
	 	              n++;
	            
	             }
	        } catch (Exception e) {
	            
	            System.out.println(e);
	        }
	        return n;
	         
	}

	public int findAllHospital() {
		int n=0;
		try {
			
			Connection con=DbHmsUtil.getDBConnection();
			 String query = "select * from hospital";
			 Statement st=con.createStatement();
			 
		ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				System.out.println("HospitalId : "+rs.getInt(1)+"\nHospitalName : "+rs.getString(2)+"\nHospitalAddress : "+rs.getString(3)+"\nHospitalPhoneNo : "+rs.getString(4)+"\nHospitalEmail : "+rs.getString(5)+"\nHospitalRating : "+rs.getFloat(6)+"\nNoOfBeds : "+rs.getInt(7));
	             n++;
			}
			
			}catch(Exception e) {
				System.out.println(e);
			}
			
			return n;
		}
	}


