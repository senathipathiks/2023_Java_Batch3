package com.hms.main;

import java.util.Scanner;

import com.hms.bean.Hospital;
import com.hms.dao.HospitalDao;



public class HMSMain {
	
	static Scanner sc=new Scanner (System.in);

	public static int displayHospitalMenu() {
		System.out.println("1.Insert 2.Delete 3.Update 4.Update All 5.FindAll 6.Find 7.Exit");
		System.out.println("Enter Your Choice");

		int choice=sc.nextInt();

		return choice;
	}
	
	public static Hospital insertHospital() {
		System.out.println("Enter HospitalId ");
		int hid=sc.nextInt();
		System.out.println("Enter HospitalName ");
		String hname=sc.next();
		System.out.println("Enter HospitalAddress ");
		String haddress=sc.next();
		System.out.println("Enter HospitalPhoneNo ");
		String hphonenNo=sc.next();
		System.out.println("Enter HospitalEmail ");
		String hemail=sc.next();
		System.out.println("Enter HospitalRating ");
		float hrating=sc.nextFloat();
		System.out.println("Enter HospitalNoOfBeds ");
		int hbeds=sc.nextInt();
		
		return new Hospital(hid,hname, haddress, hphonenNo, hemail, hrating, hbeds);
	}
	
	public static int deleteHospital() {

		System.out.println("Enter Hospital id To Delete");
		
		return (sc.nextInt());
	}
   
	public static String updateParticularColumn() {
		
		System.out.println("Enter Your  HospitalId");
		int id=sc.nextInt();
		System.out.println("Enter Your  HospitalEmail That You Need To Update");
		String hname=sc.next();		
		
		return hname;

	}
	public static Hospital updateAllHospital() {
		System.out.println("Enter HospitalId ");
		int hid=sc.nextInt();
		System.out.println("Enter HospitalName ");
		String hname=sc.next();
		System.out.println("Enter HospitalAddress ");
		String haddress=sc.next();
		System.out.println("Enter HospitalPhoneNo ");
		String hphonenNo=sc.next();
		System.out.println("Enter HospitalEmail ");
		String hemail=sc.next();
		System.out.println("Enter HospitalRating ");
		float hrating=sc.nextFloat();
		System.out.println("Enter HospitalNoOfBeds ");
		int hbeds=sc.nextInt();
		return new Hospital(hid,hname, haddress, hphonenNo, hemail, hrating, hbeds);

	}
	public static int findHospital() {
		System.out.println("Enter Your Hospital Id To Find The Hospital Details");
	int hid=sc.nextInt();
	return hid;	
	}
	
	public static void main(String[] args) {
		
		String msg="";
		int n;
		HospitalDao dao=new HospitalDao();
		do {
			switch(displayHospitalMenu()) {
			case 1:
				Hospital h1=insertHospital();
				n=dao.insertHospital(h1);
				if(n==1) {
					System.out.println("Record inserted Successfully");
				}else {
					System.out.println("Record Insertion Failed");
				}
				break;

			case 2:
				int id=deleteHospital();
				n=dao.deleteHospital(id);
				if(n==1) {
					System.out.println("Record Deleted Successfully");
				}else {
					System.out.println("Record Deletion Failed");
				}
				break;
				
			case 3:
				
				String hId=updateParticularColumn();
				n=dao.updateParticularColumn(hId);
				if(n==1) {
					System.out.println("Update Successfully");
				}else {
					System.out.println("Updation Failed");
				}
				break;
            case 4:
				
				Hospital h=updateAllHospital();
				n=dao.updateAllHospital(h);
				if(n==1) {
					System.out.println("Update Successfully");
				}else {
					System.out.println("Updation Failed");
				}
				break;
				
			case 5:
				n=dao.findAllHospital();
				if(n==1) {
					System.out.println("These All are the Values");
				}else {
					System.out.println("No Records Found");
				}
				break;
				
            case 6:
				
				int find=findHospital();
				n=dao.findHospital(find);
				if(n==1) {
					System.out.println("Here Your Column");
				}else {
					System.out.println("Failed");
				}
				break;
			
            case 7:
            	System.exit(0);
			}
			System.out.println("Do you wist to continue (yes/no)");
			msg=sc.next();
		}while(msg.equals("yes"));
	
		}

}