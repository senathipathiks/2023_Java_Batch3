package com.hms.bean;


public class Hospital {
 
	private int hospId;
	private String hospName;
	private String hospAddress;
	private String hospPhoneNo;
	private String hospEmail;
	private Float hospRating;
	private int hospNoOfBeds;
	public Hospital(int hospId, String hospName, String hospAddress, String hospPhoneNo, String hospEmail,
			Float hospRating, int hospNoOfBeds) {
		super();
		this.hospId = hospId;
		this.hospName = hospName;
		this.hospAddress = hospAddress;
		this.hospPhoneNo = hospPhoneNo;
		this.hospEmail = hospEmail;
		this.hospRating = hospRating;
		this.hospNoOfBeds = hospNoOfBeds;
	}
	public int getHospId() {
		return hospId;
	}
	public void setHospId(int hospId) {
		this.hospId = hospId;
	}
	public String getHospName() {
		return hospName;
	}
	public void setHospName(String hospName) {
		this.hospName = hospName;
	}
	public String getHospAddress() {
		return hospAddress;
	}
	public void setHospAddress(String hospAddress) {
		this.hospAddress = hospAddress;
	}
	public String getHospPhoneNo() {
		return hospPhoneNo;
	}
	public void setHospPhoneNo(String hospPhoneNo) {
		this.hospPhoneNo = hospPhoneNo;
	}
	public String getHospEmail() {
		return hospEmail;
	}
	public void setHospEmail(String hospEmail) {
		this.hospEmail = hospEmail;
	}
	public Float getHospRating() {
		return hospRating;
	}
	public void setHospRating(Float hospRating) {
		this.hospRating = hospRating;
	}
	public int getHospNoOfBeds() {
		return hospNoOfBeds;
	}
	public void setHospNoOfBeds(int hospNoOfBeds) {
		this.hospNoOfBeds = hospNoOfBeds;
	}
	@Override
	public String toString() {
		return "Hospital [hospId=" + hospId + ", hospName=" + hospName + ", hospAddress=" + hospAddress
				+ ", hospPhoneNo=" + hospPhoneNo + ", hospEmail=" + hospEmail + ", hospRating=" + hospRating
				+ ", hospNoOfBeds=" + hospNoOfBeds + "]";
	}
	
	
}
