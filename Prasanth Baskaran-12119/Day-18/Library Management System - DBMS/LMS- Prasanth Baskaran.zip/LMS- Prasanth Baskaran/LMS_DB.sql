-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: lms_db
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `bookid` int NOT NULL,
  `book_name` varchar(45) NOT NULL,
  `bk_author_name` varchar(45) NOT NULL,
  `bk_publisher` varchar(45) NOT NULL,
  `bk_cost` int DEFAULT NULL,
  `staffid` int NOT NULL,
  PRIMARY KEY (`bookid`),
  KEY `staffid` (`staffid`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`staffid`) REFERENCES `staff` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (1,'comic story','prashanth','pm publisher',1200,1);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_ret_rec`
--

DROP TABLE IF EXISTS `book_ret_rec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_ret_rec` (
  `borrowerid` int NOT NULL,
  `memberid` int NOT NULL,
  `staffid` int NOT NULL,
  `book_ret_date` date NOT NULL,
  `due` varchar(45) NOT NULL,
  `membername` varchar(45) NOT NULL,
  PRIMARY KEY (`borrowerid`),
  KEY `staffid` (`staffid`),
  KEY `memberid` (`memberid`),
  CONSTRAINT `book_ret_rec_ibfk_1` FOREIGN KEY (`staffid`) REFERENCES `staff` (`staffid`),
  CONSTRAINT `book_ret_rec_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_ret_rec`
--

LOCK TABLES `book_ret_rec` WRITE;
/*!40000 ALTER TABLE `book_ret_rec` DISABLE KEYS */;
INSERT INTO `book_ret_rec` VALUES (1,1,1,'2024-01-17','yes','Prasanth');
/*!40000 ALTER TABLE `book_ret_rec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrowrec`
--

DROP TABLE IF EXISTS `borrowrec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrowrec` (
  `borrowerid` int NOT NULL,
  `borrower_name` varchar(45) NOT NULL,
  `borrow_date` varchar(45) DEFAULT NULL,
  `memberid` int NOT NULL,
  `staffid` int DEFAULT NULL,
  PRIMARY KEY (`borrowerid`),
  KEY `staffid` (`staffid`),
  KEY `memberid` (`memberid`),
  CONSTRAINT `borrowrec_ibfk_1` FOREIGN KEY (`staffid`) REFERENCES `staff` (`staffid`),
  CONSTRAINT `borrowrec_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrowrec`
--

LOCK TABLES `borrowrec` WRITE;
/*!40000 ALTER TABLE `borrowrec` DISABLE KEYS */;
INSERT INTO `borrowrec` VALUES (1,'vishnu','2024-01-18',1,1);
/*!40000 ALTER TABLE `borrowrec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `memberid` int NOT NULL,
  `member_name` varchar(45) NOT NULL,
  `member_address` varchar(45) NOT NULL,
  `member_phone` int NOT NULL,
  `member_age` int DEFAULT NULL,
  `member_gender` varchar(45) NOT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'Prashanth','TTP',98787675,22,'male');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staffid` int NOT NULL,
  `staffname` varchar(45) NOT NULL,
  `staff_add` varchar(45) NOT NULL,
  `staff_password` varchar(45) NOT NULL,
  `staff_mail` varchar(45) DEFAULT NULL,
  `memberid` int NOT NULL,
  PRIMARY KEY (`staffid`),
  KEY `memberid` (`memberid`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'sena','com','1234567','sena@gmail',1);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-19 17:14:00
