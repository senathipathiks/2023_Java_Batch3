package com.property.main;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


import com.property.bean.PropBean;
import com.property.dao.PropDAO;

/**
 * Servlet implementation class PropMain
 */
@WebServlet("/")
public class PropMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private PropDAO propDAO;
	
	public void init() {
        propDAO = new PropDAO();
    }
	
	
	
	

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getServletPath();

		System.out.println(action);
		
		
		try {
					switch (action) {
			    case "/new":
			        showNewForm(request, response);
			        break;
			    case "/insert":
			        insertProp(request, response);
			        break;
			    case "/delete":
			        deleteProp(request, response);
			        break;
			    case "/edit":
			        showEditForm(request, response);
			        break;
			    case "/update":
			        updateProp(request, response);
			        break;
			    case "/search":
			    	searchProp(request,response);
			    	break;
			    	
			    case "/list":
			        listProp(request, response);
			        break;
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
	}
	
	//Search Property

	public void searchProp(HttpServletRequest request, HttpServletResponse response) {
		
		 int id = Integer.parseInt(request.getParameter("search"));
		
		 System.out.println(id);
		 PropDAO dao = new PropDAO();
	     try {
			PropBean exUser = dao.find(id);
			request.setAttribute("prop", exUser);
			RequestDispatcher dispatcher = request.getRequestDispatcher("search.jsp");
			
			dispatcher.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	
	
// List Property
	
	public void listProp(HttpServletRequest request, HttpServletResponse response) {
		   
		 
		PropDAO dao = new PropDAO();
		
		System.out.println("list");
		
		try {
			List<PropBean> listUser = dao.findAll();
			
			
			System.out.println(listUser);

			request.setAttribute("listProp", listUser);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
			
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		}

	// Update Property
	
	public void updateProp(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String city= request.getParameter("city");
		String country= request.getParameter("country");
		String yop= request.getParameter("yop");
		String seller= request.getParameter("seller");
		
		
	    PropBean pb = new PropBean(id, name,type, city,country,yop,seller);
		
		PropDAO dao = new PropDAO();
		
		int n = dao.updateProp(pb);
		
		if(n==1) {
			System.out.println("User value Updation Successfully !!!");
		}
		else {
			System.out.println("Updation Failed !!!");
		}
		
		response.sendRedirect("list");
			
		
		}
	
	//Edit form
	
	public void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 int id = Integer.parseInt(request.getParameter("id"));
		 PropDAO dao = new PropDAO();
	     try {
			PropBean exUser = dao.find(id);
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
			request.setAttribute("prop", exUser);
			dispatcher.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		}
	
	
   // Delete property
	
	public void deleteProp(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		PropDAO dao = new PropDAO();
		
		int n = dao.deleteProp(id);
		
		if(n==1) {
			System.out.println("User value deletion Successfully !!!");
		}
		else {
			System.out.println("deletion Failed !!!");
		}
		
		response.sendRedirect("list");
			
		}
	
	//Insert property
	
	public void insertProp(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String city= request.getParameter("city");
		String country= request.getParameter("country");
		String yop= request.getParameter("yop");
		String seller= request.getParameter("seller");
		
		
		PropBean pb = new PropBean(name,type, city,country,yop,seller);
		
		PropDAO dao = new PropDAO();
		
		int n = dao.insertProp(pb);
		
		if(n==1) {
			System.out.println("User value inserted Successfully !!!");
		}
		else {
			System.out.println("Insertion Failed !!!");
		}
		
		response.sendRedirect("list");
			
		}
	
	public static void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
	     dispatcher.forward(request, response);
	     
		
		
	}
	
}
