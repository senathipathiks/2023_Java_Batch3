package com.property.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.property.bean.PropBean;
import com.property.util.DBUtil;

public class PropDAO {

	private static final String INSERT = "INSERT INTO property(PropName,PropType,City,Country,YearofPurchase,Seller) VALUES " +
	        " (?, ?, ?,?,?,?);";

	    private static final String FIND = "select * from property where PropId =?";
	    private static final String FIND_ALL = "select * from property";
	    private static final String DELETE = "delete from property where PropId = ?;";
	    private static final String UPDATE = "update property set PropName = ?,PropType= ?, City =? , Country= ?, YearofPurchase= ?, Seller=? where PropId = ?;";
	
	    DBUtil db = new DBUtil();
		   static int n ;
		   
		   
		   public PropBean find(int id) throws SQLException {
				
		    	PropBean prop = null;
		    	
	            Connection con = db.getDBConnection();
		    	
		    	PreparedStatement ps = con.prepareStatement(FIND);
		    	
		    	 ps.setInt(1, id);
		    	 
		    	ResultSet rs   = ps.executeQuery(); 
		    	
		    	try {
					while (rs.next()) {

						String name = rs.getString("PropName");
						String type = rs.getString("PropType");
						String city = rs.getString("City");
						String country = rs.getString("Country");
						String yop = rs.getString("YearofPurchase");
						String seller = rs.getString("Seller");

						prop = new PropBean(id,name,type,city,country,yop,seller);

					} 
				} catch (Exception e) {
					e.printStackTrace();
				}
		     
		    	return prop;
		    	
		    	
		    }
		   
		   
		   
		   public List<PropBean> findAll() throws SQLException{
	             
		    	 List < PropBean > props = new ArrayList < > ();
		    	
		    	 PropBean prop = null;
		    	
	            Connection con = db.getDBConnection();
		    	
			    	PreparedStatement ps = con.prepareStatement(FIND_ALL);
			    	
			    	ResultSet rs   = ps.executeQuery(); 
			    	
		    	try {
					while (rs.next()) {
	                     
						
						int id = rs.getInt("PropId");
						
						String name = rs.getString("PropName");
						String type = rs.getString("PropType");
						String city = rs.getString("City");
						String country = rs.getString("Country");
						String yop = rs.getString("YearofPurchase");
						String seller = rs.getString("Seller");

						prop = new PropBean(id,name,type,city,country,yop,seller);
						
						
						
						props.add(prop);

					} 
					System.out.println(props);
				} catch (Exception e) {
					e.printStackTrace();
				}
		    	
				return props;
		    	
		    	
		    }
		   
		   public int updateProp(PropBean prop) throws SQLException {
				
		        try {
					  Connection con = db.getDBConnection();
			    	
			    	PreparedStatement ps = con.prepareStatement(UPDATE);
			    	
			    	System.out.println(prop);
			    	ps.setString(1, prop.getPropName());
			    	ps.setString(2, prop.getPropType());
			    	ps.setString(3, prop.getCity());
			    	ps.setString(4, prop.getCountry());
			    	ps.setString(5, prop.getYearOfPurchase());
			    	ps.setString(6, prop.getSeller());
			    	ps.setInt(7, prop.getPropId());
			    	
			    	n= ps.executeUpdate();
			    	System.out.println(n);
				} catch (Exception e) {
					e.printStackTrace();
				}
			    	
			    	
				
			    	return n;
			    }
		   
		   
		   public int deleteProp(int id) throws SQLException {
		    	
	            Connection con = db.getDBConnection();
		    	
		    	PreparedStatement ps = con.prepareStatement(DELETE);
		    	
		    	ps.setInt(1, id);
		    	
		    	 n= ps.executeUpdate();
				
		    	
		    	return n;

		    	
		    }
		   
		   public int insertProp(PropBean prop) throws SQLException {
		    	
		    	
		    	Connection con = db.getDBConnection();
		    	
		    	PreparedStatement ps = con.prepareStatement(INSERT);
		    	
		    	ps.setString(1, prop.getPropName());
		    	ps.setString(2, prop.getPropType());
		    	ps.setString(3, prop.getCity());
		    	ps.setString(4, prop.getCountry());
		    	ps.setString(5, prop.getYearOfPurchase());
		    	ps.setString(6, prop.getSeller());
		    	
		    	n= ps.executeUpdate();
				
		    	return n;
		    }
		    
}
