package com.property.bean;

public class PropBean {
	
	protected int propId;
	protected String propName;
	protected String propType;
	protected String city;
	protected String country;
	protected String yearOfPurchase;
	protected String seller;
	
	public PropBean() {
		super();
	}
	
	
	public PropBean(String propName, String propType, String city, String country, String yearOfPurchase,
			String seller) {
		super();
		this.propName = propName;
		this.propType = propType;
		this.city = city;
		this.country = country;
		this.yearOfPurchase = yearOfPurchase;
		this.seller = seller;
	}
	
	
	
	public PropBean(int propId, String propName, String propType, String city, String country, String yearOfPurchase,
			String seller) {
		
		this.propId = propId;
		this.propName = propName;
		this.propType = propType;
		this.city = city;
		this.country = country;
		this.yearOfPurchase = yearOfPurchase;
		this.seller = seller;

		
	}


	public int getPropId() {
		return propId;
	}


	public void setPropId(int propId) {
		this.propId = propId;
	}


	public String getPropName() {
		return propName;
	}


	public void setPropName(String propName) {
		this.propName = propName;
	}


	public String getPropType() {
		return propType;
	}


	public void setPropType(String propType) {
		this.propType = propType;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getYearOfPurchase() {
		return yearOfPurchase;
	}


	public void setYearOfPurchase(String yearOfPurchase) {
		this.yearOfPurchase = yearOfPurchase;
	}


	public String getSeller() {
		return seller;
	}


	public void setSeller(String seller) {
		this.seller = seller;
	}


	@Override
	public String toString() {
		return "PropBean [PropId=" + propId + ", PropName=" + propName + ", PropType=" + propType + ", City=" + city
				+ ", Country=" + country + ", YearOfPurchase=" + yearOfPurchase + ", Seller=" + seller + "]";
	}
	
	
	
	
	
	
	
	

}
